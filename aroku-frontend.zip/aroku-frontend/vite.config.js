import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Browser calls /api/... and Vite forwards it to FastAPI (no CORS needed in dev).
// Change the target if your backend runs on another port.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": {
        target: "http://localhost:8000",
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/api/, ""),
      },
    },
  },
});
